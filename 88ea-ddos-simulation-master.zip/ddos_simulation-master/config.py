# IP to attack
dst_ip = ""
# Number of IPs
n_ips = ""
# Number of messages per IP
n_msg = ""
# Interface
interface = ""
# Type
# "1" = Flood; "2"=Teardrop; "3"=Black nurse
type = ""
# IPs used
# "1" = From ips.txt; "2" = Random IPs
orig_type = ""
#Threads
threads= ""
